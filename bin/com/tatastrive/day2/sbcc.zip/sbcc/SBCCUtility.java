package com.tatastrive.day2.sbcc;

public class SBCCUtility {

	//HXCB1234D:Dhoni:5:20:130:55:102:100:North:Batsman:3
	public Player parsePlayerDetails( String playerDetails) 
	{
		Player player = null;
		
		String[] playerArr = playerDetails.split(":");
		int index=0;
		String playerId = playerArr[index++];
		String playerName=playerArr[index++];
		int matchPlayed= Integer.parseInt(playerArr[index++]);
		
		String[] runScored= new String[matchPlayed];
		
		for(int i=0;i<matchPlayed;i++)
		{
			runScored[i]=playerArr[index++];
		}
		
		String playingZone=playerArr[index++];
		
		player = new Player(playerId,playerName,matchPlayed,0,playingZone);
		
		int totalRun=player.calculateTotalRuns(runScored);
		player.setRunScored(totalRun);
		
		return player;
	}
}
