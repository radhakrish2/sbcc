package com.tatastrive.day2.sbcc;

import java.util.Scanner;

public class UserInterface {
	
	public static void main(String[] args) {
		SBCCUtility sbccUtility = new SBCCUtility();
		Scanner sc = new Scanner(System.in);
		Player player=null;
		int  choice=0;
		
		while(true)
		{
			System.out.println("1.Parse the player details and create player");
			System.out.println("2. Exit");
			System.out.println("Enter your choice");
			choice=sc.nextInt();
			sc.nextLine();
			
			switch(choice)
			{
			case 1:
				System.out.println("Enter the player details ");
				String playerDetails=sc.nextLine();
				
				player=sbccUtility.parsePlayerDetails(playerDetails);
				System.out.println("Player id:"+player.getPlayerId());
				System.out.println("Player name:"+player.getPlayerName());
				System.out.println("Matches played:"+player.getMatchesPlayed());
				System.out.println("Total runs scored:"+player.getRunScored());
				System.out.println("Playing zone:"+player.getPlayingZone());
				
				break;
				
			case 2:
				System.out.println("Thank you for using SBCC application ");
				return;
			}
		}
	}

}
